# FPS Boost (Fabric 1.21.11, client)

Build:  install JDK 21, then in this folder run
    gradle wrapper      (needs Gradle installed once)
    ./gradlew build     (Windows: gradlew.bat build)
Jar appears in build/libs/fpsboost-1.0.0.jar -> put in .minecraft/mods with Fabric API.

In game: /fpsboost on | extreme | off | status

If Gradle says a version doesn't exist, update gradle.properties from https://fabricmc.net/develop
