package com.fpsboost;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.text.Text;

/**
 * /fpsboost on        - balanced preset
 * /fpsboost extreme   - maximum FPS preset
 * /fpsboost off       - restore your previous settings
 * /fpsboost status
 */
public class FpsBoostClient implements ClientModInitializer {

    /** Snapshot of the player's settings so "off" can restore them. */
    private static class Saved {
        int view, sim, biome;
        double entityDist;
        boolean shadows;
        ParticlesMode particles;
        CloudRenderMode clouds;
    }

    private static Saved saved;
    private static String mode = "off";

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("fpsboost")
                .then(ClientCommandManager.literal("on").executes(c -> {
                    apply(false);
                    c.getSource().sendFeedback(Text.literal("FPS Boost: balanced preset ON"));
                    return 1;
                }))
                .then(ClientCommandManager.literal("extreme").executes(c -> {
                    apply(true);
                    c.getSource().sendFeedback(Text.literal("FPS Boost: EXTREME preset ON"));
                    return 1;
                }))
                .then(ClientCommandManager.literal("off").executes(c -> {
                    boolean ok = restore();
                    c.getSource().sendFeedback(Text.literal(ok
                        ? "FPS Boost OFF - previous settings restored"
                        : "FPS Boost was not active"));
                    return 1;
                }))
                .then(ClientCommandManager.literal("status").executes(c -> {
                    c.getSource().sendFeedback(Text.literal("FPS Boost mode: " + mode));
                    return 1;
                }))));
    }

    private static void apply(boolean extreme) {
        MinecraftClient mc = MinecraftClient.getInstance();
        GameOptions o = mc.options;

        if (saved == null) { // only snapshot once, so on -> extreme -> off still restores originals
            saved = new Saved();
            saved.view = o.getViewDistance().getValue();
            saved.sim = o.getSimulationDistance().getValue();
            saved.biome = o.getBiomeBlendRadius().getValue();
            saved.entityDist = o.getEntityDistanceScaling().getValue();
            saved.shadows = o.getEntityShadows().getValue();
            saved.particles = o.getParticles().getValue();
            saved.clouds = o.getCloudRenderMode().getValue();
        }

        o.getViewDistance().setValue(extreme ? 6 : 8);
        o.getSimulationDistance().setValue(extreme ? 5 : 6);
        o.getBiomeBlendRadius().setValue(extreme ? 0 : 1);
        o.getEntityDistanceScaling().setValue(extreme ? 0.5 : 0.75);
        o.getEntityShadows().setValue(false);
        o.getParticles().setValue(ParticlesMode.MINIMAL);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);

        o.write();
        mode = extreme ? "extreme" : "balanced";
    }

    private static boolean restore() {
        if (saved == null) return false;
        GameOptions o = MinecraftClient.getInstance().options;
        o.getViewDistance().setValue(saved.view);
        o.getSimulationDistance().setValue(saved.sim);
        o.getBiomeBlendRadius().setValue(saved.biome);
        o.getEntityDistanceScaling().setValue(saved.entityDist);
        o.getEntityShadows().setValue(saved.shadows);
        o.getParticles().setValue(saved.particles);
        o.getCloudRenderMode().setValue(saved.clouds);
        o.write();
        saved = null;
        mode = "off";
        return true;
    }
}
